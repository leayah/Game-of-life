﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;


namespace Assignment1Trial2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // Setting some variables
        int cellWidth = 12;         // With of the cells which will also be used to determine positions
        int cellHeight = 12;        // Height of the cells which will also be used to determine position
        bool[,] AliveCells = new bool[30, 30];
        Label[,] firstGrid = new Label[30, 30]; // This is the array that will hold the cell's information
        bool[,] NextGen = new bool[30, 30];
        int numberOfGenerations = 0;
        int genCounter = 0;


        //GroupBox groupBoxForGrid = new GroupBox(); // A panel where the cells will be laid out

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Controls.Add(groupBoxForGrid);
            groupBoxForGrid.Location = new Point(10, 10);
            groupBoxForGrid.Size = new Size(cellWidth * firstGrid.GetLength(0) + 45, cellHeight * firstGrid.GetLength(1) + 55);
            groupBoxForGrid.Visible = true;


            Label myLabel;
            for (int row = 0; row < firstGrid.GetLength(0); row++)
            {
                for (int col = 0; col < firstGrid.GetLength(1); col++)
                {
                    myLabel = new Label();
                    myLabel.Location = new Point((col * cellWidth + 20), (row * cellHeight + 30)); // Possition is assigned to cell
                    myLabel.Size = new Size(cellWidth, cellHeight);// Size is Assigned to cell
                    myLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle; //border style of the cell(AKA label)
                    myLabel.BackColor = Color.White; // the background color of the cell
                    myLabel.Tag = row * 300 + col;
                    myLabel.Name = $"{row}{col}";
                    //myLabel.Text = $"{row}{col}";
                    groupBoxForGrid.Controls.Add(myLabel); // Add the cell to the group box of grid
                    myLabel.Click += On_Click; //added click button event handler
                    firstGrid[row, col] = myLabel;


                }

            }
            setCellsToDead();
        }

        private void setCellsToDead()
        {
            for (int i = 0; i < AliveCells.GetLength(0) - 1; i++)
            {
                for (int j = 0; j < AliveCells.GetLength(1) - 1; j++)
                {
                    AliveCells[i, j] = false;

                }
            }
        }

        private void On_Click(object sender, EventArgs e)
        {
            Label labelCell = ((Label)sender);

            int row = (int)labelCell.Tag / 300;
            int col = (int)labelCell.Tag % 300;


            if (labelCell.BackColor == Color.White) // If the BackColor is white, it means it's dead so if you click on it you make it alive and it turns to green
            {
                firstGrid[row, col].BackColor = Color.Green; // Change the color to green  
                AliveCells[row, col] = true; //this cell was originally dead
            }
            else //// If the BackColor is Green, it means the cell is Alive so if you click on it you make it die and it turns back to white
            {
                firstGrid[row, col].BackColor = Color.White;
                AliveCells[row, col] = false;
            }


        }

        private int GetNeighbours(bool[,] newGenArray ,int x,int y)
        {
            int AliveNeighbourCounter = 0;

            for ( x = 0; x < AliveCells.GetLength(0) - 1; x++)
            {
                for ( y = 0; y < AliveCells.GetLength(1) - 1; y++)
                {

                    if (x == 0 && y == 0) //top left cell on corner
                    {
                        if (newGenArray[x, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on bottom right
                        if (newGenArray[x + 1, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on bottom
                        if (newGenArray[x + 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        
                    }



                    else if (x == 0 && y == firstGrid.GetLength(1) - 1) //top right cell on corner
                    {
                        //check cell on left
                        if (newGenArray[x, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on bottom left
                        if (newGenArray[x + 1, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on bottom
                        if (newGenArray[x + 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                       

                    }


                    else if (x == firstGrid.GetLength(0) - 1 && y == firstGrid.GetLength(1) - 1) //bottom right cell on corner
                    {
                        //check cell on top
                        if (newGenArray[x - 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on left
                        if (newGenArray[x, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on top left
                        if (newGenArray[x - 1, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        
                    }


                    else if (x == firstGrid.GetLength(0) - 1 && y == 0) //bottom left cell on corner
                    {

                        //check cell on top
                        if (newGenArray[x - 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on top right
                        if (newGenArray[x - 1, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on right
                        if (newGenArray[x, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        

                    }

                    else if (x == 0 && y > 0 && y < firstGrid.GetLength(1) - 1) //top edge of grid
                    {
                        //check cell on right
                        if (newGenArray[x, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on bottom right
                        if (newGenArray[x + 1, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on bottom
                        if (newGenArray[x + 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on bottom left
                        if (newGenArray[x + 1, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on left
                        if (newGenArray[x, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        
                    }


                    else if (x == firstGrid.GetLength(0) - 1 && y < firstGrid.GetLength(1) - 1 && y > 0) //bottom edge of grid
                    {
                        //check cell on right
                        if (newGenArray[x, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on left
                        if (newGenArray[x, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on top right
                        if (newGenArray[x - 1, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on top left
                        if (newGenArray[x - 1, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on top
                        if (newGenArray[x - 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        

                    }

                    else if (x > 0 && x < firstGrid.GetLength(0) - 1 && y == 0) //left edge of grid
                    {
                        //check cell on bottom
                        if (newGenArray[x + 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on top
                        if (newGenArray[x - 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on right
                        if (newGenArray[x, y + 1] == true)
                        { AliveNeighbourCounter++; }

                        //check cell on bottom right
                        if (newGenArray[x + 1, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on top right
                        if (newGenArray[x - 1, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        
                    }



                    else if (x > 0 && x < firstGrid.GetLength(0) - 1 && y > 0 && y < firstGrid.GetLength(1) - 1) //right edge of grid
                    {
                        //check cell on bottom left
                        if (newGenArray[x + 1, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on top
                        if (newGenArray[x - 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on bottom
                        if (newGenArray[x + 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }


                        //check cell on top left
                        if (newGenArray[x - 1, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }


                        //check cell on left
                        if (newGenArray[x, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }


                        
                    }

                    else if (x > 1 && x <= firstGrid.GetLength(0) - 2 && y > 1 && y <= firstGrid.GetLength(1) - 2)
                    {

                        //check cell on right
                        if (newGenArray[x, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on bottom right
                        if (newGenArray[x + 1, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on top right
                        if (newGenArray[x - 1, y + 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }



                        //check cell on top left
                        if (newGenArray[x - 1, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }

                        //check cell on bottom left
                        if (newGenArray[x + 1, y - 1] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }


                        //check cell on top
                        if (newGenArray[x - 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                            return AliveNeighbourCounter;
                        }


                        //check cell on bottom
                        if (newGenArray[x + 1, y] == true)
                        {
                            AliveNeighbourCounter++;
                             return AliveNeighbourCounter;
                        }
                       
                    }
                  
                }

            }
            return AliveNeighbourCounter;
        }

        private bool RefreshGrid()

        {
            bool cellChanged = false;

            for (int row = 0; row < firstGrid.GetLength(0) - 1; row++)
            {
                for (int col = 0; col < firstGrid.GetLength(1) - 1; col++)
                {
                    if (firstGrid[row, col].BackColor == Color.Green && (GetNeighbours(AliveCells,row,col) == 2 || GetNeighbours(AliveCells,row,col) == 3))
                    {
                        NextGen[row, col] = true;
                        AliveCells[row, col] = true;
                        firstGrid[row, col].BackColor = Color.Green;

                        cellChanged= false ;
                        return cellChanged;
                    }

                    if (firstGrid[row, col].BackColor == Color.Green && (GetNeighbours(AliveCells, row, col) >= 4 || GetNeighbours(AliveCells, row, col) <= 8))
                    {
                        NextGen[row, col] = false;
                        AliveCells[row, col] = false;
                        firstGrid[row, col].BackColor = Color.White;

                        cellChanged = true;
                        return cellChanged;
                    }

                    if (firstGrid[row, col].BackColor == Color.White && (GetNeighbours(AliveCells, row, col) ==3))
                    { 

                        NextGen[row, col] = true;
                        AliveCells[row, col] = true;
                        firstGrid[row, col].BackColor = Color.Green;

                        cellChanged = true;
                        return cellChanged;
                    }

                }
            }


            return cellChanged;
        }




        //show open file dialogue then take the values in the file selected through the dialogue and use them as coordinates 
        //to load the game of life grid with those values
        private void BtnLoadGrid_Click(object sender, EventArgs e)
        {

            string lineOfInput;                      // string to get a line from the file
            string[] numbers;                          // string array that gets the Split() of a given line from file
            char[] delimiters = { ' ', ',', '\t' };  // delimiters used to split a line from file into tokens
            int row;
            int column;
            string filepath = ""; //variable to store file path

            //open dialogue to choose file
            OpenFileDialog dialog = new OpenFileDialog();    // reference to the open file dialog
            dialog.Title = "Choose Game Of Life file";
            dialog.Filter = ".gol files(*.gol)|*.gol|All files(*.*)|*.*";
            dialog.DefaultExt = ".gol";
            dialog.FilterIndex = 1;
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                filepath = dialog.FileName;

            }
            if (result != DialogResult.OK)
            {
                MessageBox.Show("You have not selected a file ", "message to user");
                return;
            }

            //read data in file and convert them to coordinates

            StreamReader textIn = new StreamReader(new FileStream(filepath, FileMode.Open, FileAccess.Read));
            while (!textIn.EndOfStream)
            {
                try
                {
                    lineOfInput = textIn.ReadLine().Trim();
                    if (lineOfInput.Length != 0)
                    {
                        // split the line into individual tokens and then store each token in a array

                        numbers = lineOfInput.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

                        foreach (string num in numbers)
                        {

                            if (!int.TryParse(numbers[0], out row) || !int.TryParse(numbers[1], out column))
                            {
                                MessageBox.Show("Value in file contains non numeric data.");

                            }

                            else
                            {

                                AliveCells[row, column] = true;
                                firstGrid[row, column].BackColor = Color.Green;

                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"File read error: {ex.Message}.");

                }
            }


        }



        //Terminates the Application
        private void BtnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnResetAllCells_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you Sure you want to reset the Grid?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                for (int row = 0; row < firstGrid.GetLength(0); row++)
                {
                    for (int col = 0; col < firstGrid.GetLength(1); col++)
                    {

                        firstGrid[row, col].BackColor = Color.White;
                        AliveCells[row, col] = false;


                    }

                }

                groupBoxForGrid.Text = "Generation 0";
                genCounter = 0;
                btnNext.Enabled = true;
                setCellsToDead();
            }

            else if (DialogResult == DialogResult.No)
            {
                //do nothing
            }


        }


        private void writeToFile(string path)
        {
            // writeFile() - write coordinates values to specified file path
            //  Create a streamwriter object using the passed in filepath. If that fails then report the error to the user
            //  Given that we successfully create the streamwriter, use WriteLine() to output the coordinates values and then close the file. 

            StreamWriter file;

            try
            {
                file = new StreamWriter(path);

                for (int row = 0; row < firstGrid.GetLength(0); row++)
                {
                    for (int col = 0; col < firstGrid.GetLength(1); col++)
                    {
                        if (AliveCells[row, col] == true)
                        {
                            file.WriteLine($"{row},{col}");
                        }
                    }

                }

                file.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show($"File not created. {e.Message}");
            }
        }

        private void BtnSaveGrid_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();       // reference to the SaveFileDialog object.
            dialog.Title = "Save Coordinates";
            dialog.DefaultExt = ".gol";
            dialog.Filter = ".gol files(*.gol)|*.gol|All files(*.*)|*.*";
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                writeToFile(dialog.FileName);
                MessageBox.Show($"File '{dialog.FileName} written.");

            }
            if (result != DialogResult.OK)
            {
                MessageBox.Show("You have not saved the file ", "message to user");
                return;
            }

        }

        private void BtnNext_Click(object sender, EventArgs e)
        {
            genCounter++;
            groupBoxForGrid.Text = "Generation " + genCounter.ToString();

            int.TryParse(txtNumberOfGenerations.Text, out numberOfGenerations);

            for (int i = 0; i <= numberOfGenerations; i++)
            {
            
               if (!RefreshGrid())
                {
                    MessageBox.Show("The world now is stable, no more life or death can happen");
                    btnNext.Enabled = false;
                }



            }

        }

    }


}
